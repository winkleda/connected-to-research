module Bootstrap
  VERSION = '3.3.1.0'
  BOOTSTRAP_SHA = '9a7e365c2c4360335d25246dac11afb1f577210a'
end
